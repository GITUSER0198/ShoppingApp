import { Component, OnInit } from '@angular/core';
import { ProductService } from 'src/app/shared/services/product.service';

@Component({
  selector: 'app-product-image',
  templateUrl: './product-image.component.html',
  styleUrls: ['./product-image.component.css']
})
export class ProductImageComponent implements OnInit {

  image
  constructor(private productService:ProductService) { }

  ngOnInit(): void {
    this.image=this.productService.image
    console.log(this.image);
  }

}
