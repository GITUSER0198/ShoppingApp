import { Component, OnInit } from '@angular/core';
import { ProductService } from 'src/app/shared/services/product.service';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Product } from 'src/app/shared/product';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { DomSanitizer } from '@angular/platform-browser';
import { ProductImageComponent } from './product-image/product-image.component';


@Component({
  selector: 'app-listproducts',
  templateUrl: './listproducts.component.html',
  styleUrls: ['./listproducts.component.css']
})
export class ListproductsComponent implements OnInit {

  image

  product_name


  public productList
  public completeList

  formData:Product;
  selectedFile:File=null;

  constructor(
    public productService:ProductService,
    private dialog:MatDialog,
    private router:Router,
    private toaster:ToastrService,
    private sanitizer:DomSanitizer
  ) { }

    
productModel:Product
  
  ngOnInit(): void {
    this.productModel={
      Product_id:null,
      Product_name:null,
      Product_category:null,
      Product_Image:null,
      Product_description:null,
      Product_price:null,
      Product_quantity:null   
  }
  this.productService.getProducts().then(
    res=>
    {
   
       this.completeList=res;
       let objectURL = 'data:image/png;base64,' + this.completeList.product_Image;
       this.completeList.product_Image = this.sanitizer.bypassSecurityTrustUrl(objectURL);
       this.productList=this.completeList;
    
    }
  )

}

  addProduct()
  {
    this.router.navigate(['/addproduct']);
  }



  populateForm(product)
    {
      
      this.productService.product=product
      this.router.navigate(['/addproduct', { value:"edit" }])
    
    }
  Search()
  {
      if(this.product_name==""){
            this.ngOnInit();
          }
          else{
        this.productList=this.completeList.filter(res=>{
          if(res.product_name!=null)
          return res.product_name.toLocaleLowerCase().match(this.product_name.toLocaleLowerCase())});

        }
  }
  logout()
  {
    localStorage.removeItem("jwt");
    localStorage.removeItem("user");
    location.reload();
    
  }

  openImage(image)
  {
    this.productService.image=image
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose=true;
    this.dialog.open(ProductImageComponent, dialogConfig);
  }



}
