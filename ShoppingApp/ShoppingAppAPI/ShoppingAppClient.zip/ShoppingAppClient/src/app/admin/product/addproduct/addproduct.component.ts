import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute,Router } from '@angular/router';
import { Product } from 'src/app/shared/product';
import { ProductService } from 'src/app/shared/services/product.service';

@Component({
  selector: 'app-addproduct',
  templateUrl: './addproduct.component.html',
  styleUrls: ['./addproduct.component.css']
})
export class AddproductComponent implements OnInit {

  title: string = "Create";  
  selectedFile: File = null;
  value
  constructor(public productService:ProductService,
    private router:Router,
    private route:ActivatedRoute) { 
    
    this.route.params.subscribe(params => {
      this.value = params['value'];
    });
  }
  productModel:Product
  
  ngOnInit(): void {

    if(this.value=="edit")
    {
      this.productService.productForm.patchValue({
        id:this.productService.product.product_id,
        name:this.productService.product.product_name,
        category:this.productService.product.product_category,
        quantity:this.productService.product.product_quantity,
        price:this.productService.product.product_price,
        description:this.productService.product.product_description        
      });

    }
    else
    {
      this.productService.productForm.reset();
    }
  
  }


  addProduct(data)
  {
    this.productService.addProduct(data,this.selectedFile);
  }
  logout()
  {
    localStorage.removeItem("jwt");
    localStorage.removeItem("user");
    location.reload();
    
  }

  handleFileInput(fileInput: any) {
    this.selectedFile = <File>fileInput.target.files[0];
  }
  resetProductForm()
  {
    this.productService.productForm.reset();
    
  }
}
