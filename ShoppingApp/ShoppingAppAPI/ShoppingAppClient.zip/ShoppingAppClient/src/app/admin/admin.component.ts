import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { CustomerService } from '../shared/services/customer.service';
import { OrderService } from '../shared/services/order.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  list:any;
  completeList:any;
  customer_email:any;
  // searchBox;
  public term;
  constructor(
    private customerService:CustomerService,
    private router:Router,
    private toaster:ToastrService,
  ) { }

  ngOnInit(): void {
    if(localStorage.getItem('user')!='admin@gmail.com')
    {
    this.router.navigate(['login']);
    }
    this.customerService.getCustomers().then(
      response => {
        if (!response) {
          console.log(Error)
        } else {
           this.completeList  = response;
           this.completeList=this.completeList.filter(x=>x.customer_email!="admin@gmail.com")
           this.list=this.completeList.filter(x=>x.customer_email!="admin@gmail.com")
          }
      })
  }

 
  logout()
  {
    localStorage.removeItem("jwt");
    localStorage.removeItem("user");
    location.reload();
    
  }
  blockUser(id)
  {
    
    this.customerService.blockUser(id)
    .then(
      response=>{
        if(!response)
        {
          console.log(Error);
        }
        else
        {
          if(response>0)
          {
            this.toaster.success("User blocked");
            setTimeout(
              function(){ 
              location.reload(); 
              }, 500);    
          }
          else
          {
            if(confirm('Something went wrong')){
              location.reload();  
          }
          }
        }
      }
    )

  }

  
  Search()
  {

      if(this.customer_email==""){
            this.ngOnInit();
          }
          else{
        this.list=this.completeList.filter(res=>{
          if(res.customer_email!=null)
          return res.customer_email.toLocaleLowerCase().match(this.customer_email.toLocaleLowerCase())});

        }
  }


  
  unBlockUser(id)
  {
    this.customerService.unBlockUser(id).then(
      response=>{
        if(!response)
        {
          console.log(Error)
        }
        else
        {
          if(response>0)
          {
            this.toaster.success("User UnBlocked");
            setTimeout(
              function(){ 
              location.reload(); 
              }, 500);    
          
          }
          else
          {           
            if(confirm('Something went wrong')){
              location.reload();  
            }
          }
        }
      }
    )
  }

}
