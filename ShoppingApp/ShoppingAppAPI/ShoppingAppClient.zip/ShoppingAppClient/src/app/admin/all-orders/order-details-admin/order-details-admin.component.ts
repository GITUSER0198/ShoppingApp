import { Component, OnInit } from '@angular/core';
import { OrderService } from 'src/app/shared/services/order.service';

@Component({
  selector: 'app-order-details-admin',
  templateUrl: './order-details-admin.component.html',
  styleUrls: ['./order-details-admin.component.css']
})
export class OrderDetailsAdminComponent implements OnInit {

  orderDetail:any=[]
  orders:any[]
  user
  constructor(public orderService:OrderService) { }
  
  ngOnInit(): void {
    this.orderService.getOrderDetails(this.orderService.order.order_id).then(res=>{
      this.orderDetail=res;
    })
    console.log(this.orderService.order)
  }
  
}
