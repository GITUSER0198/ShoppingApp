import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { OrderService } from 'src/app/shared/services/order.service';
import { AdminComponent } from '../admin.component';

@Component({
  selector: 'app-all-orders',
  templateUrl: './all-orders.component.html',
  styleUrls: ['./all-orders.component.css']
})
export class AllOrdersComponent implements OnInit {

  constructor(private orderService:OrderService,
    private router:Router) { }
    orderList
  ngOnInit(): void {
    this.orderService.getOrders().then(res=>{
      if(!res)
      {
        console.log(Error);
      }
      this.orderList=res;
     // console.log(this.orderList)
      this.orderList=this.orderList;
      this.orderList=this.orderList.sort((order1,order2)=> 
      {return this.compareObjects(order1,order2, 'order_date')
      })

    })
  }
  getDetails(order)
  {
    this.orderService.order=order
    this.router.navigate(['/orderdetailsadmin'])
    
  }

  compareObjects(object1, object2, key) {
    const obj1 = object1[key].toUpperCase()
    const obj2 = object2[key].toUpperCase()
  
    if (obj1 < obj2) {
      return 1
    }
    if (obj1 > obj2) {
      return -1
    }
    return 0
  }


}
