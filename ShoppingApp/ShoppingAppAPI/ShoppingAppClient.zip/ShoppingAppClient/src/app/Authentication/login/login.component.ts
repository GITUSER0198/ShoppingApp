import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, NgForm, Validators } from '@angular/forms';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { AuthService } from '../../shared/services/auth.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {


  // loginForm:FormGroup;
  
  invalidLogin=true;
 
  hide=true;

  constructor(
    private router:Router,
    private http:HttpClient,
    public authService:AuthService,
    private formBuilder: FormBuilder,
    private toaster:ToastrService
    ){ }

    ngOnInit(): void {
   
    }
    
    onSubmit()
    {
      if(this.authService.loginForm.invalid)
      {
        return;
      }

       this.authService.login()
       .subscribe(
        (res:any)=>{
            const token = (<any>res).token;
             localStorage.setItem("jwt", token);
             localStorage.setItem("user",res.email);
             localStorage.setItem("Customer_id",res.customer_id)
             this.invalidLogin = false
             if(localStorage.getItem('user')=='admin@gmail.com')
             {
               this.router.navigate(["/admin"]);
             }
             else
             {
              this.router.navigate(["/"]);
             }
          }
        ,
        err=>{

          console.log(err);
          if(err.error.message=="Customer is blocked")
          {
            this.toaster.error("User is blocked");
          }
          else
          {
            this.toaster.error("Invalid details");
          }
        }
      )    



    //   this.http.post("http://localhost:52238/api/customer/login", credentials, {
    //   headers: new HttpHeaders({
    //     "Content-Type": "application/json"
    //   })
    // }).subscribe(response => {
    //   const token = (<any>response).token;
    //   localStorage.setItem("jwt", token);
    //   this.invalidLogin = false;
    //   this.router.navigate(["/"]);
    // }, err => {
    //   this.invalidLogin = true;
    // });

    
    }


 
  

}
