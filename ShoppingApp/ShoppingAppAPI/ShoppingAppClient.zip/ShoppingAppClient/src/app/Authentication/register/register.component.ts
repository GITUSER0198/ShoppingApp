import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import { AuthService } from '../../shared/services/auth.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';




@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})

export class RegisterComponent implements OnInit {

  hide = true;
  hide2=true;
  
  constructor(
    private formBuilder: FormBuilder,
    private http:HttpClient,
    public authService:AuthService,
    private toaster:ToastrService,
    private router:Router
  ) { }
  ngOnInit(): void {


  }


  onSubmit()
  {
        if(this.authService.registerForm.invalid)
        {
          return;
        }
        this.authService.register()
        .subscribe(
        (res:any)=>{
          if(res.message=="Customer is blocked")
          {
            this.toaster.error("User is blocked");
          }
          else
          {
            if(res.code>0)
          {
            this.authService.registerForm.reset();
            this.toaster.success('New user created!','Registeration successful ')
            const token = (<any>res).token;
             localStorage.setItem("jwt", token);
             localStorage.setItem("user",res.email);
             localStorage.setItem("Customer_id",res.customer_id)
             this.router.navigate(["/"]);

          }
          else if(res.message==="Customer is already registered")
          {
            console.log(res);
            this.toaster.error('User already exists!','Registeration failed ')

          }
          }
          
        },
        err=>{
         console.log(err);
        }
      )    

  }


}
