import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';

@Injectable({
  providedIn: 'root'
})
export class OrderService {

  orders
  cartTotal
  order
  orderId
  cartItems:any=[]

  apiUrl='/api/order'
  orderList
  orderDetails
  checkOutForm=new FormGroup({
    address:new FormControl(null,[Validators.required]),
    pincode:new FormControl(null,[Validators.required,Validators.pattern('[1-9][0-9]{5}')]),
    mobile:new FormControl(null,[Validators.required,Validators.pattern('[7-9][0-9]{9}')])
  })
  constructor(private http:HttpClient,
              private toaster:ToastrService) { }

              
  addOrder()
  {
    
    if(localStorage.getItem('user')==null)
    {
      this.toaster.error('Please login')
    }
    else
    {
    
      let formData =  new FormData();

      formData.set('user',localStorage.getItem('user'))
      formData.set('cartTotal',this.cartTotal)
      formData.set('address',this.checkOutForm.value.address)
      formData.set('pincode',this.checkOutForm.value.pincode)
      formData.set('mobile',this.checkOutForm.value.mobile) 
      formData.set('ordersLength',this.orders.length)
      for (var i = 0; i < this.orders.length; i++) {
        formData.set('orders'+[i]+'.product_id',this.orders[i].product_id)
        formData.set('orders'+[i]+'.product_name',this.orders[i].product_name)
        formData.set('orders'+[i]+'.product_quantity',this.orders[i].product_quantity)   

    }
      this.http.post<any>(this.apiUrl+'/createorder',formData)
     .subscribe(res=>{
  
        this.orderId=res.code;
        this.toaster.success('New order placed'); 
        this.checkOutForm.reset();
        localStorage.removeItem('cart');
        this.cartTotal=0
        this.cartItems=[]
    
     })

    }
    
  }

  getOrders()
  {
   return this.http.get(this.apiUrl+'/getcustomerorders').toPromise().then(res=>this.orderList=res)
  }

  getOrderDetails(id)
  {
    return this.http.get(this.apiUrl+'/getorderdetails/'+id).toPromise().then(res=>this.orderDetails=res)
  }

  addProductToCart(product)
  {
  
    let productExists=false;
    for(let i in this.cartItems)
    { 
       if(this.cartItems[i].product_id===product.product_id)
      {
        productExists=true;
  
        if(product.product_quantity<=this.cartItems[i].product_quantity)
        {
          this.toaster.error('Maximum quantity exceeded');
  
        }
        else
        {
          this.cartItems[i].product_quantity++
          break;
        }
      
      }
    }
    if(!productExists)
    {
      this.cartItems.push({
        product_id:product.product_id,
        product_name:product.product_name,
        product_price:product.product_price,
        product_quantity:1
      })
    }
  
       
        this.cartTotal=0;
        this.cartItems.forEach(item=>{
          this.cartTotal+=(item.product_quantity*item.product_price)
        })
    localStorage.setItem('cart',JSON.stringify(this.cartItems))
  
  }
  
  removeProductFromCart(cartItem)
  {
    console.log(cartItem);
    for(let i in this.cartItems)
    {
      if(this.cartItems[i].product_id===cartItem.product_id)
      {
        this.cartItems[i].product_quantity--
        if(this.cartItems[i].product_quantity<=0)
        {
         
          this.cartItems=this.cartItems.filter(x=>x.product_id!=cartItem.product_id)
         
        }
      }
      
    }
    this.cartTotal=0;
    this.cartItems.forEach(item=>{
      this.cartTotal+=(item.product_quantity*item.product_price)
    })
    localStorage.setItem('cart',JSON.stringify(this.cartItems))
    if(this.cartItems.length==0)
    {
      localStorage.removeItem('cart');
    }
  }

  

}



