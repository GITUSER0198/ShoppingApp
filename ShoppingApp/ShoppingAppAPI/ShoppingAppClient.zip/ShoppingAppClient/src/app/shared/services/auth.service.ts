import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AbstractControl, FormControl, FormGroup, NgForm, ValidationErrors, Validators } from '@angular/forms';
import { Observable } from 'rxjs';
import { catchError, mapTo, tap } from 'rxjs/operators';
import { of } from 'rxjs';
import { Router } from '@angular/router';


class CustomValidators{
  static passwordValid(control:AbstractControl):ValidationErrors{
    const regex=/^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{8,16}$/;
  
    if(regex.test(control.value)&&control.value!==null)
    {
      return null;
    }
    else
    {
      return {passwordInvalid:true};
    }
  }

  static passwordMatch(control:AbstractControl):ValidationErrors{
    const password=control.get("password").value;
    const confirmPassword=control.get("confirmPassword").value;
    
    if((password===confirmPassword)&&(password!==null &&confirmPassword!==null))
    {
      return null;
    }
    else
    {
      return{passwordNotMatch:true};
    }

  }
   static MatchPassword(control: AbstractControl) {
      let parent = control.parent
      if (parent) {
        let password = parent.get('password').value;
        let confirmPassword = control.value;

        if (password != confirmPassword) {
          return { ConfirmPassword: true };
        } else {
          return null
        }
      } else {
        return null;
      }
    }
  
}


@Injectable({
  providedIn: 'root'
})
export class AuthService {

  apiUrl='/api/auth'
  invalidLogin=true;
  loginForm=new FormGroup({
    Customer_email:new FormControl(null,[Validators.required,Validators.email]),
    password:new FormControl(null,[Validators.required])
  })

  registerForm=new FormGroup({
    email:new FormControl(null,[Validators.required,Validators.email]),
    password:new FormControl(null,[Validators.required,CustomValidators.passwordValid]),
    confirmPassword:new FormControl(null,[Validators.required,CustomValidators.MatchPassword]),
    firstName:new FormControl(null,[Validators.required,Validators.pattern('[a-zA-Z]+')]),
    lastName:new FormControl(null,[Validators.required,Validators.pattern('[a-zA-Z]+')]),
    mobile:new FormControl(null,[Validators.required,Validators.pattern('[7-9][0-9]{9}')])
  })

  username
  password

  constructor(
    private http:HttpClient,
    private router:Router
      ) { }

 
    register()
    {
      var body={
        Customer_email:this.registerForm.value.email,
        Customer_password:this.registerForm.value.password,
        Customer_firstName:this.registerForm.value.firstName,
        Customer_lastName:this.registerForm.value.lastName,
        Customer_mobile:this.registerForm.value.mobile,
        Customer_status:true
      }
        this.username=this.registerForm.value.email;
        this.password=this.registerForm.value.password;

      return this.http.post<any>(this.apiUrl+'/register', body,{headers:new HttpHeaders({
        "Content-Type": "application/json"
      })})
    
    }

    login()
    { 
      
      var body={
        Customer_email:this.loginForm.value.Customer_email,
        Customer_password:this.loginForm.value.password,
      }
      return this.http.post<any>(this.apiUrl+'/login', body,{headers:new HttpHeaders({
        "Content-Type": "application/json"
      })})  
    }


            
       
     
        
}


