import { HttpClient, HttpHeaders} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { DomSanitizer } from '@angular/platform-browser';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  image
  productList
  product
  completeList
  constructor(
    private http:HttpClient,
    private toaster:ToastrService,
    private router:Router,
    private sanitizer: DomSanitizer
  ) { }

  apiUrl='/api/product'

  public productForm=new FormGroup({
    id:new FormControl(0),
    name:new FormControl(null,[Validators.required,Validators.pattern('[a-zA-Z-,]+(\s{0,1}[a-zA-Z-, ])*')]),
    category:new FormControl(null,[Validators.required]),
    quantity:new FormControl(null,[Validators.required,Validators.pattern('[0-9]{1,}')]),
    price:new FormControl(null,[Validators.required,Validators.pattern('(\\d+)(\\.)?(\\d+)?')]),
    description:new FormControl(null,[Validators.required]),
    image:new FormControl(null)
  })



  
  getProducts()
  {
     return this.http.get(this.apiUrl+'/allproducts').toPromise().then()

      
  }

  addProduct(data,file)
  {
    const token=localStorage.getItem('jwt');
    const headers = new HttpHeaders({Authorization: `Bearer ${token}`});


    let formData =  new FormData();
    formData.set('Product_id',data.id)
    formData.set('Product_name', data.name);
    formData.set('Product_category',data.category);
    formData.set('Product_quantity',data.quantity);
    formData.set('Product_price',data.price);
    formData.set('Product_description',data.description);
    formData.set('Image',file);
    
    if(data.id==null||data.id==0)
    {    
      this.http.post<any>(this.apiUrl+'/addproduct',formData,{headers:headers})
      .subscribe(res => {
        this.toaster.success('New product added');
        this.productForm.reset();
        setTimeout(
          function(){ 
          }, 500);
          
      })
        }
    else
    {
    
      this.http.post<any>(this.apiUrl+'/editproduct',formData)
      .subscribe(res=>{
     
      })
      this.toaster.success('Product updated');
      this.productForm.reset();
      setTimeout(
        function(){ 
        }, 500);

      }

  }

  
  deleteProduct(id)
  {
    return this.http.delete(this.apiUrl+'/deleteproduct/'+id)
    .subscribe(res=>{
      if(Error)
      {
        console.log(Error);
      }
      if(res==1)
      {
        this.toaster.success('Product deleted');
        setTimeout(
          function(){ 
          location.reload(); 
          }, 500);
        
      }
      else
      {
        alert('Error in deleting product');
      }

    })
  }

  getProduct(id)
  {
    return this.http.get(this.apiUrl+'/getproduct/'+id)
  

  }
  editProduct(product)
  {
     return  this.http.put(this.apiUrl +'/editproduct/', product)
     .subscribe(res=>{
      if(Error)
      {
        console.log(Error);
      }
      if(res==1)
      {
        this.toaster.success('Product updated');
        setTimeout(
          function(){ 
          location.reload(); 
          }, 500);
      }
    }
   )
  }
  
   

}
