import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  constructor(private http:HttpClient) { }

  apiUrl='/api/customer'
  list;
  status;

  getCustomers()
  {
    return this.http.get(this.apiUrl+'/AllCustomerList').toPromise().then(res => this.list = res );
  }

  blockUser(id)
  {
    
    return this.http.post(this.apiUrl+'/blockcustomer/',id).toPromise().then(res=>this.status=res);
  }
  unBlockUser(id)
  {
    return this.http.post(this.apiUrl+'/unblockcustomer/',id).toPromise().then(res=>this.status=res);
  }


}
