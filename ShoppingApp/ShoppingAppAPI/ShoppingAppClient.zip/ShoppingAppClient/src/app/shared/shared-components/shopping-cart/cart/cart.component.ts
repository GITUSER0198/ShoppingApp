import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { OrderService } from 'src/app/shared/services/order.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  constructor(
    public orderService:OrderService,
    private router:Router,
    private toaster:ToastrService) { }

  ngOnInit(): void {
  
  this.orderService.cartTotal=0;
  if(localStorage.getItem('cart'))
  {
      this.orderService.cartItems=JSON.parse(localStorage.getItem('cart'));
      this.orderService.cartItems.forEach(item=>{
      this.orderService.cartTotal+=(item.product_quantity*item.product_price)
      })
  }
  // this.orderService.cartItems.forEach(item=>{
  //   this.orderService.cartTotal+=(item.product_quantity*item.product_price)
  // })
  //localStorage.setItem('cart',JSON.stringify(this.orderService.cartItems))

    // this.msg.getMsg().subscribe((product:any)=>
    //   {
    //     this.orderService.addProductToCart(product);
    //   })


      // this.msg.getCartItem().subscribe((cartItem:any)=>
      // {
      //   this.removeProductFromCart(cartItem);
      // })

  }

  // removeProductFromCart(cartItem)
  // {
  //   for(let i in this.orderService.cartItems)
  //   {
  //     if(this.orderService.cartItems[i].product_id===cartItem.product_id)
  //     {
  //       this.orderService.cartItems[i].product_quantity--
  //       if(this.orderService.cartItems[i].product_quantity<=0)
  //       {
  //         this.orderService.cartItems.pop({
  //           product_id:cartItem.product_id
          
  //         })
         
  //       }
  //     }
      
  //   }
  //   this.orderService.cartTotal=0;
  //   this.orderService.cartItems.forEach(item=>{
  //     this.orderService.cartTotal+=(item.product_quantity*item.product_price)
  //   })
  //   localStorage.setItem('cart',JSON.stringify(this.orderService.cartItems))
  //   if(this.orderService.cartItems.length==0)
  //   {
  //     localStorage.removeItem('cart');
  //   }
  // }


  // addProductToCart(product)
  // {
  //  // event.preventDefault();

  //   let productExists=false;
  //   for(let i in this.orderService.cartItems)
  //   { 
  //      if(this.orderService.cartItems[i].product_id===product.product_id)
  //     {
  //       productExists=true;

  //       if(product.product_quantity<=this.orderService.cartItems[i].product_quantity)
  //       {
  //         this.toaster.error('Maximum quantity exceeded');

  //       }
  //       else
  //       {
  //         this.orderService.cartItems[i].product_quantity++
  //         break;
  //       }
      
  //     }
  //   }
  //   if(!productExists)
  //   {
  //     this.orderService.cartItems.push({
  //       product_id:product.product_id,
  //       product_name:product.product_name,
  //       product_price:product.product_price,
  //       product_quantity:1
  //     })
  //   }
  
       
  //       this.orderService.cartTotal=0;
  //       this.orderService.cartItems.forEach(item=>{
  //         this.orderService.cartTotal+=(item.product_quantity*item.product_price)
  //       })
  //   localStorage.setItem('cart',JSON.stringify(this.orderService.cartItems))

  // }

  checkout()
  {
    
    this.orderService.orders=this.orderService.cartItems
    this.router.navigate(['checkout']);

  }
}
