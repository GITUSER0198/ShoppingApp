import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { OrderService } from '../../services/order.service';

@Component({
  selector: 'app-order-history',
  templateUrl: './order-history.component.html',
  styleUrls: ['./order-history.component.css']
})
export class OrderHistoryComponent implements OnInit {

  constructor(private orderService:OrderService,
    private router:Router) { }
  orderList

  
  ngOnInit(): void {
  this.orderService.getOrders().then(res=>{
    if(!res)
    {
      console.log(Error);
    }
    this.orderList=res;
    this.orderList=this.orderList.filter(res=>{
      if(res.customer_id!=null)
      return res.customer_id ==localStorage.getItem('Customer_id')}); 
        this.orderList=this.orderList.sort((order1,order2)=> 
          {return this.compareObjects(order1,order2, 'order_date')
          })

        }
      )
  }

  getDetails(order)
  {
    this.orderService.order=order
    this.orderService.orderId=order.order_id
    this.router.navigate(['/orderdetails'])
    
  }
  compareObjects(object1, object2, key) {
    const obj1 = object1[key].toUpperCase()
    const obj2 = object2[key].toUpperCase()
  
    if (obj1 < obj2) {
      return 1
    }
    if (obj1 > obj2) {
      return -1
    }
    return 0
  }
}
