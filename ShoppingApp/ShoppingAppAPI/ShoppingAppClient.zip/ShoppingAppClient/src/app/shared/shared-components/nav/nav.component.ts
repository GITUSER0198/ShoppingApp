import { Component, OnInit } from '@angular/core';
import { JwtHelperService } from '@auth0/angular-jwt';

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.css']
})
export class NavComponent implements OnInit {

  authenticated=false
  isAdmin=false;
  isUser=false;
  constructor(private jwtHelper:JwtHelperService) { }

  ngOnInit(): void {
    if(this.isUserAuthenticated())
    {
      this.authenticated=true;
    }
    if(localStorage.getItem('user')=="admin@gmail.com")
    {
      this.isAdmin=true;
    }
    if(localStorage.getItem('user')!="admin@gmail.com"&&localStorage.getItem('user')!=null)
    {
      this.isUser=true;
    }

  
  }
  
  isUserAuthenticated() {
    const token: string = localStorage.getItem("jwt");
  
    if (token && !this.jwtHelper.isTokenExpired(token)) {
      return true;
    }
    else {
  
      return false;
    }
  }
  logout()
  {
    localStorage.removeItem("jwt");
    localStorage.removeItem("user");
    location.reload();
    
  }

}
