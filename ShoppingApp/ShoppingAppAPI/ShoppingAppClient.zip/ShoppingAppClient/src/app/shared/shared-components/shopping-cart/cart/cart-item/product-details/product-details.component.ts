import { Component, OnInit } from '@angular/core';
import { OrderService } from 'src/app/shared/services/order.service';
import { ProductService } from 'src/app/shared/services/product.service';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {

  constructor(private productService:ProductService,
    private orderService:OrderService) { }

  product
  ngOnInit(): void {
  this.product=this.productService.product;

  console.log(this.product);
  }
  handleAddToCart(product)
  {
    this.orderService.addProductToCart(product)
  }


}
