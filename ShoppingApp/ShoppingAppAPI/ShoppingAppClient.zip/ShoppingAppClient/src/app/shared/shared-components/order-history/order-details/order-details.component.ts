import { Component, OnInit } from '@angular/core';
import { OrderService } from 'src/app/shared/services/order.service';

@Component({
  selector: 'app-order-details',
  templateUrl: './order-details.component.html',
  styleUrls: ['./order-details.component.css']
})
export class OrderDetailsComponent implements OnInit {

  orderDetail:any=[]
  orders:any[]
  user
  constructor(public orderService:OrderService) { }
  ngOnInit(): void {
    this.orderService.getOrderDetails(this.orderService.orderId).then(res=>{
      this.orderDetail=res;
    })
    this.orders=this.orderService.orderList.filter(res=>{
      if(res.customer_id!=null)
      return res.customer_id ==localStorage.getItem('Customer_id')}); 
      this.user=localStorage.getItem('user');
  }
}
