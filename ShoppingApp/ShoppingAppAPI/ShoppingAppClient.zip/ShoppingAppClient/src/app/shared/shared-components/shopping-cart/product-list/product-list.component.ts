import { Component, OnInit } from '@angular/core';
import { ProductService } from 'src/app/shared/services/product.service';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {

  completeList
  productList
  product_name
  filterCategoryList
  constructor(public productService:ProductService,
    private sanitizer:DomSanitizer
    ) { }

  ngOnInit(): void {
    
    this.productService.getProducts().then(
      res=>
      {
        if(Error)
        {
          console.log(Error)
        }
          
         this.completeList=res;
         let objectURL = 'data:image/png;base64,' + this.completeList.product_Image;
         this.completeList.product_Image = this.sanitizer.bypassSecurityTrustUrl(objectURL);
         this.productList=this.completeList;
          this.filterCategoryList=this.completeList;
          
      }
    )


  }
  Search()
  {
      if(this.product_name==""){
            this.productList=this.filterCategoryList
          }
          else{
        this.productList=this.filterCategoryList.filter(res=>{
          if(res.product_name!=null)
          return res.product_name.toLocaleLowerCase().match(this.product_name.toLocaleLowerCase())});

        }
  }


  filterCategory(value)
  {
    if(value=="Filter")
    {
      this.filterCategoryList=this.completeList;
      this.productList=this.filterCategoryList;
    }   
    else
    {
      this.filterCategoryList=this.completeList.filter(res=>{
        if(res.product_category!=null)
        return res.product_category.toLocaleLowerCase().match(value.toLocaleLowerCase())}); 
        this.productList=this.filterCategoryList
    }
   
  }
}
