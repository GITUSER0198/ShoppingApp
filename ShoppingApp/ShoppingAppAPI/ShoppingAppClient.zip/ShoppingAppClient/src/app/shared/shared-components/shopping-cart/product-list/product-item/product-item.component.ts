import { Component, Input, OnInit } from '@angular/core';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { OrderService } from 'src/app/shared/services/order.service';
import { ProductService } from 'src/app/shared/services/product.service';
import { ProductDetailsComponent } from '../../cart/cart-item/product-details/product-details.component';

@Component({
  selector: 'app-product-item',
  templateUrl: './product-item.component.html',
  styleUrls: ['./product-item.component.css']
})
export class ProductItemComponent implements OnInit {

  @Input()
  productItem

  constructor(
    private orderService:OrderService,
    private dialog:MatDialog,private productService:ProductService) { }

  ngOnInit(): void {
  }

  handleAddToCart(product)
  {
    this.orderService.addProductToCart(product)
  }

  viewDetails(productItem)
  {
    const dialogConfig = new MatDialogConfig();
     dialogConfig.disableClose=true;
    this.productService.product=productItem
    this.dialog.open(ProductDetailsComponent,{width:'40%',height:'auto'})

  }

}
