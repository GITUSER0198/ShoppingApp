export class Token {
    jwt: string;
    refreshToken: string;
}
