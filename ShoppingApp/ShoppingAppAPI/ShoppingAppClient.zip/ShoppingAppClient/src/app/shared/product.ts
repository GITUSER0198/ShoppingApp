export class Product {
    Product_id:number;
    Product_name:string;
    Product_category:string;
    Product_quantity:number;
    Product_price:number;
    Product_description:string;
    Product_Image:any;
}
