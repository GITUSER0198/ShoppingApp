import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminComponent } from './admin/admin.component';
import { AllOrdersComponent } from './admin/all-orders/all-orders.component';
import { AuthguardService } from './Authentication/auth/authguard.service';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './Authentication/login/login.component';
import { NotFoundComponent } from './not-found/not-found.component';
import { OrderDetailsComponent } from './shared/shared-components/order-history/order-details/order-details.component';
import { OrderHistoryComponent } from './shared/shared-components/order-history/order-history.component';
import { AddproductComponent } from './admin/product/addproduct/addproduct.component';
import { ListproductsComponent } from './admin/product/listproducts/listproducts.component';
import { ProductComponent } from './admin/product/product/product.component';
import { RegisterComponent } from './Authentication/register/register.component';
import { CheckoutComponent } from './shared/shared-components/shopping-cart/cart/checkout/checkout.component';
import { OrderDetailsAdminComponent } from './admin/all-orders/order-details-admin/order-details-admin.component';


const routes: Routes = [
  {path:'',component:HomeComponent},
  {path:'login',component:LoginComponent},
  {path:'register',component:RegisterComponent},
  {path:'admin',component:AdminComponent,canActivate:[AuthguardService]},
  {path:'listproducts',component:ListproductsComponent,canActivate:[AuthguardService]},
  {path:'addproduct',component:AddproductComponent,canActivate:[AuthguardService]},
  {path:'product',component:ProductComponent,canActivate:[AuthguardService]},
  {path:'orderhistory',component:OrderHistoryComponent,canActivate:[AuthguardService]},
  {path:'checkout',component:CheckoutComponent,canActivate:[AuthguardService]},
  {path:'orderdetails',component:OrderDetailsComponent,canActivate:[AuthguardService]},
  {path:'orderdetailsadmin',component:OrderDetailsAdminComponent,canActivate:[AuthguardService]},
  {path:'allorders',component:AllOrdersComponent,canActivate:[AuthguardService]},
  {path:"**",component:NotFoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { 


}
