import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './Authentication/login/login.component';
import { HomeComponent } from './home/home.component';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { JwtModule } from '@auth0/angular-jwt';
import { AuthguardService } from './Authentication/auth/authguard.service';
import { RegisterComponent } from './Authentication/register/register.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatInputModule} from '@angular/material/input'
import {MatButtonModule} from '@angular/material/button'
import{MatSelectModule} from '@angular/material/select'
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatSidenavModule} from '@angular/material/sidenav';
import { AuthService } from './shared/services/auth.service';
import {ToastrModule} from 'ngx-toastr'
import { MatIconModule } from '@angular/material/icon';
import { AdminComponent } from './admin/admin.component';
import { AddproductComponent } from './admin/product/addproduct/addproduct.component';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { ListproductsComponent } from './admin/product/listproducts/listproducts.component';
import{MatDialogModule} from '@angular/material/dialog';
import {MatTabsModule} from '@angular/material/tabs';
import { ProductComponent } from './admin/product/product/product.component'
import {MatCardModule} from '@angular/material/card';
import { ProductService } from './shared/services/product.service';
import { NavComponent } from './shared/shared-components/nav/nav.component';
import { ShoppingCartComponent } from './shared/shared-components/shopping-cart/shopping-cart.component';
import { ProductListComponent } from './shared/shared-components/shopping-cart/product-list/product-list.component';
import { CartComponent } from './shared/shared-components/shopping-cart/cart/cart.component';
import { CartItemComponent } from './shared/shared-components/shopping-cart/cart/cart-item/cart-item.component';
import { ProductItemComponent } from './shared/shared-components/shopping-cart/product-list/product-item/product-item.component';
import { NotFoundComponent } from './not-found/not-found.component';
import { OrderService } from './shared/services/order.service';
import { OrderHistoryComponent } from './shared/shared-components/order-history/order-history.component';
import { CheckoutComponent } from './shared/shared-components/shopping-cart/cart/checkout/checkout.component';
import { OrderDetailsComponent } from './shared/shared-components/order-history/order-details/order-details.component';
import { AllOrdersComponent } from './admin/all-orders/all-orders.component';
import { FlexLayoutModule } from '@angular/flex-layout';
import {MatListModule} from '@angular/material/list';
import { OrderDetailsAdminComponent } from './admin/all-orders/order-details-admin/order-details-admin.component';
import { ProductImageComponent } from './admin/product/listproducts/product-image/product-image.component';
import { ProductDetailsComponent } from './shared/shared-components/shopping-cart/cart/cart-item/product-details/product-details.component';

export function tokenGetter() {
  return localStorage.getItem('jwt');
}

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    RegisterComponent,
    AdminComponent,
    AddproductComponent,
    ListproductsComponent,
    ProductComponent,
    NavComponent,
    ShoppingCartComponent,
    ProductListComponent,
    CartComponent,
    CartItemComponent,
    ProductItemComponent,
    NotFoundComponent,
    OrderHistoryComponent,
    CheckoutComponent,
    OrderDetailsComponent,
    AllOrdersComponent,
    OrderDetailsAdminComponent,
    ProductImageComponent,
    ProductDetailsComponent,
    ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,
    HttpClientModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    Ng2SearchPipeModule,
    BrowserAnimationsModule,
    MatSelectModule ,
    MatDialogModule,
    MatCardModule,
    FlexLayoutModule,
    MatToolbarModule,
    MatListModule,
    MatSidenavModule,
    MatTabsModule,
    CommonModule,
    ToastrModule.forRoot(),
    JwtModule.forRoot({
      config:{
        tokenGetter:tokenGetter,
        allowedDomains:["localhost:52238"],
        disallowedRoutes:[]
      }
     }),
  ],
  
  providers: [AuthguardService,AuthService,ProductService,OrderService],
  bootstrap: [AppComponent],
  entryComponents:[ProductImageComponent]
})
export class AppModule {
  
 }
